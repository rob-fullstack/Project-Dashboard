CREATE TABLE IF NOT EXISTS `dashboards` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` int(11) NOT NULL,
`title` text COLLATE utf8_unicode_ci,
`data` text COLLATE utf8_unicode_ci,
`color` VARCHAR(15) NOT NULL,
`sort` INT(11) NOT NULL DEFAULT '0',
`deleted` tinyint(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

CREATE TABLE IF NOT EXISTS `custom_widgets` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` int(11) NOT NULL,
`title` text COLLATE utf8_unicode_ci,
`content` text COLLATE utf8_unicode_ci,
`show_title` TINYINT(1) NOT NULL DEFAULT '0',
`show_border` TINYINT(1) NOT NULL DEFAULT '0',
`deleted` TINYINT(1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

ALTER TABLE `expenses` ADD `tax_id` INT(11) NOT NULL DEFAULT '0' AFTER `user_id`, ADD `tax_id2` INT(11) NOT NULL DEFAULT '0' AFTER `tax_id`;#

ALTER TABLE `invoices` ADD `discount_amount` DOUBLE NOT NULL AFTER `recurring_reminder_date`, ADD `discount_amount_type` ENUM('percentage','fixed_amount') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `discount_amount`, ADD `discount_type` ENUM('before_tax','after_tax') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `discount_amount_type`;#

ALTER TABLE `invoices` CHANGE `next_recurring_date` `next_recurring_date` DATE NOT NULL, CHANGE `due_reminder_date` `due_reminder_date` DATE NOT NULL, CHANGE `recurring_reminder_date` `recurring_reminder_date` DATE NOT NULL;#

ALTER TABLE `invoice_items` ADD `sort` INT(11) NOT NULL DEFAULT '0' AFTER `total`;#

ALTER TABLE `projects` ADD `estimate_id` INT(11) NOT NULL AFTER `starred_by`;#

ALTER TABLE `estimates` ADD `project_id` INT NULL DEFAULT '0' AFTER `tax_id2`;#

ALTER TABLE `checklist_items` ADD `sort` INT(11) NOT NULL DEFAULT '0' AFTER `task_id`;#







