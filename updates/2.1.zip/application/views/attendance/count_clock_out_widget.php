<div class="panel panel-coral">
    <div class="panel-body ">
        <div class="widget-icon">
            <i class="fa fa-history"></i>
        </div>
        <div class="widget-details">
            <h1><?php echo $members_clocked_out; ?></h1>
            <?php echo lang("members_clocked_out"); ?>
        </div>
    </div>
</div>