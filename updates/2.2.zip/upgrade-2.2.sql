ALTER TABLE `project_files` ADD `file_id` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL AFTER `file_name`, ADD `service_type` VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL AFTER `file_id`;#

ALTER TABLE `general_files` ADD `file_id` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL AFTER `file_name`, ADD `service_type` VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL AFTER `file_id`;#
	
INSERT INTO `settings` (`setting_name`, `setting_value`, `type`, `deleted`) VALUES ('signin_page_background', 'sigin-background-image.jpg', 'app', '0');#

INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'project_completed', 'project', '0', '0', '', '', '', '2', '0');#

ALTER TABLE `tasks` ADD `ticket_id` INT(11) NOT NULL AFTER `sort`;#

ALTER TABLE `tickets` ADD `task_id` INT(11) NOT NULL AFTER `labels`;#

ALTER TABLE `tickets` ADD `closed_at` DATETIME NOT NULL AFTER `task_id`;#

ALTER TABLE `tickets` ADD `creator_name` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `assigned_to`, ADD `creator_email` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `creator_name`;#

ALTER TABLE `invoices` CHANGE `status` `status` ENUM('draft','not_paid','cancelled') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft';#

ALTER TABLE `invoices` ADD `cancelled_at` DATETIME NULL AFTER `discount_type`, ADD `cancelled_by` INT(11) NOT NULL AFTER `cancelled_at`;#

ALTER TABLE `estimates` ADD `discount_type` enum('before_tax','after_tax') COLLATE utf8_unicode_ci NOT NULL AFTER `tax_id2`;#

ALTER TABLE `estimates` ADD `discount_amount` double NOT NULL AFTER `discount_type`;#

ALTER TABLE `estimates` ADD `discount_amount_type` enum('percentage','fixed_amount') COLLATE utf8_unicode_ci NOT NULL AFTER `discount_amount`;#

