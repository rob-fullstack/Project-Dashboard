<?php

//initialize pusher autoload
require(dirname(__FILE__) . '/vendor/autoload.php');
