<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//don't change or add new config in this file

$config['app_version'] = '2.2.1';

$config['app_update_url'] = 'http://releases.fairsketch.com/rise/';

$config['updates_path'] = './updates/';